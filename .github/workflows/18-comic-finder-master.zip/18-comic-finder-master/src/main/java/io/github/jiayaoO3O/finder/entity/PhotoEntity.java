package io.github.jiayaoO3O.finder.entity;

/**
 * Created by jiayao on 2021/3/23.
 */
public record PhotoEntity(String name, String url) {
}
