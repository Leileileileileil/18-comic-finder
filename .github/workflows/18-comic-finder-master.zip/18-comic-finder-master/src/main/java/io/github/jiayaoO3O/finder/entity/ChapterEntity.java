package io.github.jiayaoO3O.finder.entity;

import java.util.Date;

/**
 * Created by jiayao on 2021/3/23.
 */
public record ChapterEntity(int id, String name, String url) {
}
